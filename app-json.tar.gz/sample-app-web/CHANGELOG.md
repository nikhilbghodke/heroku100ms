# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.9.1](https://github.com/100mslive/sample-app-web/compare/v0.9.0...v0.9.1) (2020-12-03)

### 0.8.1 (2020-11-17)


### Features

* pick token generation endpoint from ENV ([61644b9](https://github.com/100mslive/sample-app-web/commit/61644b9ca8d119efcfcc9531352216ab60b966f0))
